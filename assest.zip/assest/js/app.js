const cl = console.log;


const stdForm = document.getElementById('stdForm');
const stdContainer = document.getElementById('stdContainer');
const fnameControl = document.getElementById('fname');
const lnameControl = document.getElementById('lname');
const emailControl = document.getElementById('email');
const contactControl = document.getElementById('contact');
const submitStdBtn = document.getElementById('submitStdBtn');
const updateStdBTn = document.getElementById('updateStdBtn');


const snackbar = (msg, icon) => {
    Swal.fire({
        title: msg,
        icon: icon,
        timer: 2500
      });
}

function uuidv4() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'
    .replace(/[xy]/g, function (c) {
        const r = Math.random() * 16 | 0, 
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}


let stdArr = JSON.parse(localStorage.getItem("stdArr")) || []

const onStdEdit = (ele) => {
    let editid = ele.closest('tr').id
    localStorage.setItem('editid', editid)
    let editobj = stdArr.find(std => std.stdId === editid);
    fnameControl.value = editobj.fname;
    lnameControl.value = editobj.lname;
    emailControl.value = editobj.email;
    contactControl.value = editobj.contact;

    submitStdBtn.classList.add('d-none')
    updateStdBTn.classList.remove('d-none')
}



const onStdRemove = (ele) => {
    let removeId = ele.closest('tr').id;
    let removeIndex = stdArr.findIndex(std => std.stdId === removeId);
    stdArr.splice(removeIndex, 1)

    localStorage.setItem("stdArr", JSON.stringify(stdArr))

    templtingOfStd(stdArr)

    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        
    }).then((result) => {
        if (result.isConfirmed) {
            
            let removeIndex = stdArr.findIndex(std => std.stdId === removeId);

            if (removeIndex === -1) {
                console.error('Student not found in the array!');
                return;
            }
            stdArr.splice(removeIndex, 1);
            localStorage.setItem("stdArr", JSON.stringify(stdArr));
            templtingOfStd(stdArr);
            snackbar('Student has been removed!', 'success');
        } else {
            console.log('Student removal canceled.');
        }
    });
}



const templtingOfStd = (arr) => {
    let result = '';

    arr.forEach((std, i) => {
        result += `
                            <tr id="${std.stdId}">
                                <td>${i + 1}</td>
                                <td>${std.fname}</td>
                                <td>${std.lname}</td>
                                <td>${std.email}</td>
                                <td>${std.contact}</td>
                                <td>
                                    <button class="btn btn-sm btn-outline-info" onclick="onStdEdit(this)">Edit</button>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger" onclick="onStdRemove(this)">Remove</button>
                                </td>
                            </tr>
                            `
    });
    stdContainer.innerHTML = result;
}
templtingOfStd(stdArr)



const onStdAdd = (eve) => {
    eve.preventDefault();
     

    let stdObj = {
        fname : fnameControl.value,
        lname : lnameControl.value,
        email : emailControl.value,
        contact : contactControl.value,
        stdId : uuidv4()
    }
    cl(stdObj);

    stdForm.reset();

    stdArr.push(stdObj);

    localStorage.setItem("stdArr", JSON.stringify(stdArr))

    let tr = document.createElement('tr');
    tr.id = stdObj.stdId;
    tr.innerHTML = `
                                <td>${stdArr.length}</td>
                                <td>${stdObj.fname}</td>
                                <td>${stdObj.lname}</td>
                                <td>${stdObj.email}</td>
                                <td>${stdObj.contact}</td>
                                <td>
                                    <button class="btn btn-sm btn-outline-info" onclick="onStdEdit(this)">Edit</button>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger" onclick="onStdRemove(this)">Remove</button>
                                </td>
                                `;

    stdContainer.append(tr);

    snackbar(`new student ${stdObj.fname} ${stdObj.lname} is added successfully !!!`, 'success')

}

const onStdUpdate = () => {

    let updateStdid = localStorage.getItem('editid')
    let updateobj = {
        fname : fnameControl.value,
        lname : lnameControl.value,
        email : emailControl.value,
        contact : contactControl.value,
        stdId : updateStdid,
    }
    stdForm.reset();

    let getIndex = stdArr.findIndex(std => std.stdId === updateStdid);
    stdArr[getIndex] = updateobj;

    localStorage.setItem("stdArr", JSON.stringify(stdArr))

    let trChild = [...document.getElementById(updateStdid).children];
    cl(trChild)

    trChild[1].innerHTML = updateobj.fname;
    trChild[2].innerHTML = updateobj.lname;
    trChild[3].innerHTML = updateobj.email;
    trChild[4].innerHTML = updateobj.contact;


    updateStdBTn.classList.add('d-none');
    submitStdBtn.classList.remove('d-none');

    snackbar(`student info id updated successfully !!!`, 'success')

}



stdForm.addEventListener("submit", onStdAdd)
updateStdBTn.addEventListener("click", onStdUpdate)


